package com.example.y_barham.breathleaf;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class ActivityLog extends AppCompatActivity {
protected ListView SessionList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        SessionList = findViewById(R.id.SessionList);
      //loadListView();
      //on item listener to go to information activity
       


            }
        };
//protected Void loadListView()
  //      {
  //          DatabaseHelper dphelper = new DatabaseHelper(this);
// List<Session> sessions = dbhelper.getAllSessions();
    //Arraylist<String> sessionsListText = new ArrayList<>();
//for (int i=0; i<sessions.size(); i++{
//{
 //   String
  //      } temp =""
//temp+=sessions.get(i).getNumber()+"\n";
//temp+=sesssions.get(i).getDate()+"\n";
//temp+=sessions.get(i).getTime()+"\n";
//temp+=sessions.get(i).getDuration()+"\n"
//SessionsListText.add(temp);
  //      }}

// ArrayAdaoter arrayAdapter = new ArrayAdapter<Stting>(this,android.R.layout.simple_list_item_1,SessionsListText);

//SessionsListText.setAdapter(arrayAdapter);}




