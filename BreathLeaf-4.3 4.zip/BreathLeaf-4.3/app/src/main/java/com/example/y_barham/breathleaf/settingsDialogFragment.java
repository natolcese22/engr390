package com.example.y_barham.breathleaf;

import android.app.DialogFragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

public class settingsDialogFragment extends DialogFragment {
    protected Switch doNotDisturbSwitch;
    protected Switch vocalGuideSwitch;
    protected Switch musicSwitch;
    protected Switch visualsSwitch;
    protected Button dismissButton;

    public static final String SHARED_PREFS = "sharedprefs";
    public static final String DONOTDISTURBSWITCH = "doNotDisturbSwitch";
    public static final String VOCALGUIDESWITCH ="vocalGuideSwitch";
    public static final String MUSICSWITCH ="musicSwitch";
    public static final String VISUALSWITCH ="visualSwitch";



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        doNotDisturbSwitch = view.findViewById(R.id.doNotDisturbSwitch);
        vocalGuideSwitch = view.findViewById(R.id.vocalGuideSwitch);
        musicSwitch = view.findViewById(R.id.musicSwitch);
        visualsSwitch = view.findViewById(R.id.visualsSwitch);
        dismissButton = view.findViewById(R.id.dismissButton);

        // load the previously saved status
        loadData();


        // save the checked status when the user changes.
        doNotDisturbSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
                sharedPreferences.edit()
                        .putBoolean(DONOTDISTURBSWITCH, isChecked)
                        .apply();
            }
        });

        vocalGuideSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
                sharedPreferences.edit()
                        .putBoolean(VOCALGUIDESWITCH, isChecked)
                        .apply();
            }
        });

        musicSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
                sharedPreferences.edit()
                        .putBoolean(MUSICSWITCH, isChecked)
                        .apply();
            }
        });

        visualsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
                sharedPreferences.edit()
                        .putBoolean(VISUALSWITCH, isChecked)
                        .apply();
            }
        });



        dismissButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });

        return view;
    }

    public void loadData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        doNotDisturbSwitch.setChecked(sharedPreferences.getBoolean(DONOTDISTURBSWITCH, false));
        vocalGuideSwitch.setChecked(sharedPreferences.getBoolean(VOCALGUIDESWITCH,false));
        musicSwitch.setChecked(sharedPreferences.getBoolean(MUSICSWITCH,false));
        visualsSwitch.setChecked(sharedPreferences.getBoolean(VISUALSWITCH,false));
    }

}